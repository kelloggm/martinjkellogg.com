/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type TownSettingsUpdate = {
    isPubliclyListed?: boolean;
    friendlyName?: string;
};

