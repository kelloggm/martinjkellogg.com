export default class Ship {
}
