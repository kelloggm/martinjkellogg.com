using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Text;
using System.IO;

public class ArrayNull {

    Object[][] a = new Object[][] {new Object[] {null}, null};
}
