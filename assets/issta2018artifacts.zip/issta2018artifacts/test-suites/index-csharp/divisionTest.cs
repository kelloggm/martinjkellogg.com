using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Text;
using System.IO;

class divisionTest {

    public static void division() {
        Console.WriteLine(1 / (2.0));
    }
}
