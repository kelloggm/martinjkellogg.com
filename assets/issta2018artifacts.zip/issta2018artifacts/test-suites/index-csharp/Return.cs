class Return {
    int[] test() {
        return null;
    }
}
