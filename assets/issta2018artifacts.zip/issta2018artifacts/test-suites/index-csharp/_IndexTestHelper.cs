﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class TestHelper
{
    public static bool nondet_value;
    public static bool nondet()
    {
        return nondet_value;
    }
}
