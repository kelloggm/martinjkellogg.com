#!/usr/bin/env bash

source ./util/util-functions.sh

# this script creates the submission to the artificat evaluation for ISSTA 2018

rm *~ || true
rm -rf guava jfreechart plume-lib jsr308 || true
rm util/*~ || true
cd ..
zip -r issta2018artifacts.zip reproduction/
echo "zipping complete. Find the resulting zip one directory above the directory this script ran in."
