#!/usr/bin/env bash

source ./util/util-functions.sh

# this script runs FindBugs version 3.0.1 on each case study. It is expected to produce no output, since FindBugs neither has any false positives nor any true positives related to arrays over these case studies.

clone_all

FINDBUGS=`pwd`/findbugs-3.0.1/lib/findbugs.jar
RANGEONLYXML=`pwd`/rangeonly.xml
SERVLET=`pwd`/javax.servlet-api-3.1.0.jar

# plume-lib

cd plume-lib/java/src
java -jar $FINDBUGS -textui -include $RANGEONLYXML -auxclasspath ../lib plume
cd ../../..

# jfreechart

cd jfreechart
# mvn compile -B -q
cd target/classes/org/jfree
java -jar $FINDBUGS -textui -include $RANGEONLYXML -auxclasspath $SERVLET chart data
cd ../../../../../

# guava

cd guava/guava/
# mvn compile -B -q "-Dcheck.index.phase=none"
cd target/classes/com/google/common
java -jar $FINDBUGS -textui -include $RANGEONLYXML base primitives
cd ../../../../../../../
